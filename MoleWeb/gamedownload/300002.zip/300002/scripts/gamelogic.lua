-- ������Ϸ���õ��Ĺ�������
dofile("scripts\\common.lua");

-- ���ڴ�����Ϸ��������Ϣ����
dofile("scripts\\networklogic.lua");

--�����������߼�
dofile("scripts\\wuziqilogic.lua");

--
-- ��Ϸ���º������¼�
--
function OnProcessGameUpdate()

end

--
-- ��Ⱦ��Ϸ����
--
function DrawScene()

end

--
-- �û�������Ϸ���õ�����Դ
-- 
function LoadGameResources()
	engine:LoadGUIConfig("gui\\gameloginframe.gui");
    
    -- ��ʼ����
    InitChessPan(totalrow,totallist);
    
    -- �����ʼ���ӷ�����
    --engine:StartGameTimer(IDD_TIMER_CONNECT_SERVER,1000);
end

-- 
-- ���ڴ�����Ϸ���¼�
-- event ��ϵͳ�д�������Ҫ��������Ϸ�¼�����Щ�¼�������������꣬GUI�������¼�
--
function OnProcessGameEvent(event)
	myevent = toHelper.toMolEvent(event);
	
	if myevent.mEventType == mole2d.MOLET_GUI_EVENT then                      -- GUI�¼�
		if myevent.mGuiEvent.EventType == mole2d.MOLGET_BUTTON_CLICKED then
			ctrlId = myevent.mGuiEvent.Caller:GetID();			
			if ctrlId == IDD_MAINFRAME_START_GAME then           -- ��ʼ��Ϸ
                ResetChessPan(); 
                
                -- �����ǰ����Ϸ��¼
                local myTextarea = toHelper.toMolGUITextarea(engine.__CMolBaseGUIContainer__:FindControlById(IDD_MAINFRAME_CHAT_MESSAGE));
                if myTextarea then
                    myTextarea:Clear();
                end
                
                -- ����ѡ��ͼƬ
                if chessselimage then
                    chessselimage:SetVisible(false);
                end
                
                -- ��������
                engine:EffectPlay("sounds\\startgame.wav");
                
                -- ���������������׼����Ϣ
                local out = mole2d.CMolMessageOut(IDD_MESSAGE_ROOM);
                out:writeShort(m_RoomId);
                out:writeShort(IDD_MESSAGE_READY_START);
                engine:Send(out);
                
                engine.__CMolBaseGUIContainer__:EnableControlById(IDD_MAINFRAME_START_GAME,false);
            elseif ctrlId == IDD_MAINFRAME_CLOSE_GAME then       -- �ر���Ϸ
                m_gamestate = GAMESTATE_PAUSE;
                engine:ShowGUIContainer(IDD_EXITTIPDIG,"gui\\exittipdialog.gui",mole2d.SANPSTYLE_CENTER);
            elseif ctrlId == IDD_MAINFRAME_HUOQI_BTN then        -- �������
                local out = mole2d.CMolMessageOut(IDD_MESSAGE_ROOM);
                out:writeShort(m_RoomId);
                out:writeShort(IDD_MESSAGE_GAMING);
                out:writeShort(IDD_MESSAGE_GAMING_HUOQI);
                out:writeShort(m_playerRoomIndex);
                
                engine:Send(out);
                
                engine.__CMolBaseGUIContainer__:EnableControlById(IDD_MAINFRAME_HUOQI_BTN,false);
            elseif ctrlId == IDD_MAINFRAME_RENSHU_BTN then       -- ����
                local out = mole2d.CMolMessageOut(IDD_MESSAGE_ROOM);
                out:writeShort(m_RoomId);
                out:writeShort(IDD_MESSAGE_GAMING);
                out:writeShort(IDD_MESSAGE_GAMING_RENSHU);
                out:writeShort(m_playerRoomIndex);
                
                engine:Send(out);
                
                engine.__CMolBaseGUIContainer__:EnableControlById(IDD_MAINFRAME_RENSHU_BTN,false);
            elseif ctrlId == IDD_QIUHEDIG_OK then                -- ��Ϸ������ʾ��ȷ����ť
                local out = mole2d.CMolMessageOut(IDD_MESSAGE_ROOM);
                out:writeShort(m_RoomId);
                out:writeShort(IDD_MESSAGE_GAMING);
                out:writeShort(IDD_MESSAGE_GAMING_HUOQI_OK);
                out:writeShort(m_playerRoomIndex);
                
                engine:Send(out);
                
                engine.__CMolBaseGUIContainer__:ShowControlById(IDD_QIUHEDIG,false);  
            elseif ctrlId == IDD_QIUHEDIG_CONCEL then            -- ��Ϸ������ʾ��ȡ����ť
                local out = mole2d.CMolMessageOut(IDD_MESSAGE_ROOM);
                out:writeShort(m_RoomId);
                out:writeShort(IDD_MESSAGE_GAMING);
                out:writeShort(IDD_MESSAGE_GAMING_HUOQI_CONCEL);
                out:writeShort(m_playerRoomIndex);
                
                engine:Send(out);
                
                engine.__CMolBaseGUIContainer__:ShowControlById(IDD_QIUHEDIG,false);  
            elseif ctrlId == IDD_EXITTIPDIG_OK then              -- �ر���Ϸ��ʾ��ȷ����ť
                engine:CloseGameFrame();
            elseif ctrlId == IDD_EXITTIPDIG_CONCEL then          -- �ر���Ϸ��ʾ��ȡ����ť
                engine.__CMolBaseGUIContainer__:ShowControlById(IDD_EXITTIPDIG,false);
            elseif ctrlId == IDD_MAINFRAME_SENDCHAT_BTN then     -- ����������Ϣ
                myCtrl = engine.__CMolBaseGUIContainer__:FindControlById(IDD_MAINFRAME_CHAT_INPUT);
                myEditor = toHelper.toMolGUIEditorBox(myCtrl);
                
                if myEditor and myEditor:GetText() ~= "" then                  
                    -- ����������Ϣ���������
                    local out = mole2d.CMolMessageOut(IDD_MESSAGE_ROOM);
                    out:writeShort(m_RoomId);
                    out:writeShort(IDD_MESSAGE_GAMING);
                    out:writeShort(IDD_MESSAGE_GAMING_CHAT);
                    out:writeShort(m_playerRoomIndex);
                    out:writeString(myEditor:GetText());
                    engine:Send(out);
                    
                    myEditor:SetText("");
                end
            end
        end
    elseif myevent.mEventType == mole2d.MOLET_MOUSE_INPUT_EVENT then          -- ����¼�
        if myevent.mMouseEvent.EventType == mole2d.MOLMIE_LMOUSE_PRESSED_DOWN then
            local MouseposX = myevent.mMouseEvent.X;
            local MouseposY = myevent.mMouseEvent.Y;
            
            if m_gamestate == GAMESTATE_GAMING then
                if ProcessMouse(MouseposX,MouseposY,m_playerRoomIndex+1) then
                    m_gamestate = GAMESTATE_PAUSE;
                    
                    -- ����ѡ��ͼƬ
                    if chessselimage then
                        chessselimage:SetVisible(false);
                    end
                    
                    --engine:SystemLog(mole2d.INFO,"�û�:"..tostring(m_playerRoomIndex).."��������:"..tostring(MouseposX).." "..tostring(MouseposY));
                                       
                    -- ��������������ҵ�����Ϣ
                    local out = mole2d.CMolMessageOut(IDD_MESSAGE_ROOM);
                    out:writeShort(m_RoomId);
                    out:writeShort(IDD_MESSAGE_GAMING);
                    out:writeShort(IDD_MESSAGE_GAMING_DIANZI);
                    out:writeShort(m_playerRoomIndex);
                    out:writeShort(MouseposX);
                    out:writeShort(MouseposY);
                    engine:Send(out);                  
                end
            end
        elseif myevent.mMouseEvent.EventType == mole2d.MOLMIE_MOUSE_MOVED then
            local MouseposX = myevent.mMouseEvent.X;
            local MouseposY = myevent.mMouseEvent.Y;
            
            if m_gamestate == GAMESTATE_GAMING then
                -- ����Ϸ״̬�¸������λ����ʾѡ��ͼƬ
                ProcessChessSelect(MouseposX,MouseposY);
            end
        end
	elseif myevent.mEventType == mole2d.MOLET_GAME_VIDEO_EVENT then           -- ��Ƶ�¼�

	elseif myevent.mEventType == mole2d.MOLET_KEY_INPUT_EVENT then                   -- �����¼�
		if myevent.mKeyEvent.Key == mole2d.KEY_RETURN and myevent.mKeyEvent.isPressedDown then
			myCtrl = engine.__CMolBaseGUIContainer__:FindControlById(IDD_MAINFRAME_CHAT_INPUT);
			myactive = engine.__CMolBaseGUIContainer__:GetCurActiveControl();
			
			if myCtrl == myactive then
				myEditor = toHelper.toMolGUIEditorBox(myCtrl);
				if myEditor and myEditor:GetText() ~= "" then                  
                    -- ����������Ϣ���������
                    local out = mole2d.CMolMessageOut(IDD_MESSAGE_ROOM);
                    out:writeShort(m_RoomId);
                    out:writeShort(IDD_MESSAGE_GAMING);
                    out:writeShort(IDD_MESSAGE_GAMING_CHAT);
                    out:writeShort(m_playerRoomIndex);
                    out:writeString(myEditor:GetText());
                    engine:Send(out);
                    
                    myEditor:SetText("");
				end
			end
        elseif myevent.mKeyEvent.Key == mole2d.KEY_F2 and myevent.mKeyEvent.isPressedDown then
            engine:SwitchScreenAndWindow();
		end
	end	
end

--
-- ���ڴ�����Ϸ�ж�ʱ���¼�
-- IDEvent Ҫ��������Ϸ�еĶ�ʱ��ID
--
function OnProcessGameTimer(IDEvent)
    if IDEvent == IDD_TIMER_CONNECT_SERVER then             -- ������Ϸ������
        engine:Connect("127.0.0.1",1234);
        engine:StopGameTimer(IDD_TIMER_CONNECT_SERVER);
    end
end
