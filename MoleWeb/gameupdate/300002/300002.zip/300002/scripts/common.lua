engine = mole2d.CMolBaseFrame:getSingleton();
