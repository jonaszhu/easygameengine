-- ������Ϸ�����粿����ϢЭ��
dofile("scripts\\defines.lua");

-- 
-- ���ڴ�����Ϸ�������¼�
-- state ��ǰ����״̬
-- msg �ӷ��������յ�Ҫ������������Ϣ
--
function OnProcessGameNetwork(state,msg)
	if state == mole2d.NOCONNECT then
		SetConnectionTip("����������ʧ��!");
	elseif state == mole2d.CONNECTTING then
		SetConnectionTip("����������������,���Ժ�...");	
	elseif state == mole2d.CONNECTED then
		SetConnectionTip("���������ӳɹ�!");	
	elseif state == mole2d.MESPROCESS then
		local myMsg = toHelper.toMolMessageIn(msg);
        local myMsgId = myMsg:getId();
        
       if myMsgId == IDD_MESSAGE_ROOM then            -- ��Ϸ������Ϣ
            local myMsgSubId = myMsg:readShort();
            
            if myMsgSubId == IDD_MESSAGE_ENTER_ROOM then     -- ����ҽ��뷿��
                m_RoomId = myMsg:readShort();
                local playerId = myMsg:readLong();

                if m_playerId == 0 then
					m_playerId = playerId;
                    engine:SystemLog(mole2d.INFO,"���:"..tostring(playerId).."������Ϸ����:"..tostring(m_RoomId));
                     
                    m_playerRoomIndex = myMsg:readShort();
                    engine:LoadGUIConfig("gui\\gamemainframe.gui");
                    
                    -- ��������ѡ��ͼƬ
                    LoadChessSelImage();
                else
					local myTextarea = toHelper.toMolGUITextarea(engine.__CMolBaseGUIContainer__:FindControlById(IDD_MAINFRAME_CHAT_MESSAGE));
					if myTextarea then
						myTextarea:AddString("���:"..tostring(playerId).." ���뷿�䡣",mole2d.CMolColor(255,255,0,0));
					end
                end
            elseif myMsgSubId == IDD_MESSAGE_GAME_START then       -- ��ʼ��Ϸ
                local playerId = myMsg:readShort();
                
                if playerId == m_playerRoomIndex then
                    m_gamestate = GAMESTATE_GAMING;
                end
                
                local myTextarea = toHelper.toMolGUITextarea(engine.__CMolBaseGUIContainer__:FindControlById(IDD_MAINFRAME_CHAT_MESSAGE));
                if myTextarea then
                    myTextarea:AddString("���:"..tostring(playerId).." ��ʼ���ӡ�",mole2d.CMolColor(255,255,0,0));
                end
                
                engine.__CMolBaseGUIContainer__:EnableControlById(IDD_MAINFRAME_HUIQI_BTN,true);
                engine.__CMolBaseGUIContainer__:EnableControlById(IDD_MAINFRAME_HUOQI_BTN,true);
                engine.__CMolBaseGUIContainer__:EnableControlById(IDD_MAINFRAME_RENSHU_BTN,true);
            end
        elseif myMsgId == IDD_MESSAGE_GAMING then            -- ��Ϸ����Ϣ
            local myMsgSubId = myMsg:readShort();
            
            if myMsgSubId == IDD_MESSAGE_GAMING_DIANZI then        -- ��ҵ�����Ϣ
                local playerId = myMsg:readShort();
                local oldplayerId = myMsg:readShort();
                local oldposx = myMsg:readShort();
                local oldposy = myMsg:readShort();
                
                if playerId == m_playerRoomIndex then   
                    ProcessMouse(oldposx,oldposy,oldplayerId+1);
                    m_gamestate = GAMESTATE_GAMING;
                end
                
                -- ���ŵ�������
                engine:EffectPlay("sounds\\dianzi"..tostring(playerId)..".wav");
                
                local myTextarea = toHelper.toMolGUITextarea(engine.__CMolBaseGUIContainer__:FindControlById(IDD_MAINFRAME_CHAT_MESSAGE));
                if myTextarea then
                    myTextarea:AddString("���:"..tostring(playerId).." ��ʼ���ӡ�",mole2d.CMolColor(255,255,0,0));
                end
            elseif myMsgSubId == IDD_MESSAGE_GAMING_CHAT then          -- ���������Ϣ
                local playerId = myMsg:readShort();
                local chat = myMsg:readString();
                
                local myTextarea = toHelper.toMolGUITextarea(engine.__CMolBaseGUIContainer__:FindControlById(IDD_MAINFRAME_CHAT_MESSAGE));
                if myTextarea then
                    myTextarea:AddString("���:"..tostring(playerId)..chat,mole2d.CMolColor(255,255,255,255));
                end
            elseif myMsgSubId == IDD_MESSAGE_GAMING_HUOQI then         -- �����������
                local playerId = myMsg:readShort();
                
                m_gamestate = GAMESTATE_PAUSE;                
                if playerId ~= m_playerRoomIndex then                    
                    engine:ShowGUIContainer(IDD_QIUHEDIG,"gui\\qiuhuodialog.gui",mole2d.SANPSTYLE_CENTER);
                end
            elseif myMsgSubId == IDD_MESSAGE_GAMING_HUOQI_CONCEL then    -- ���˲�ͬ�����
                local playerId = myMsg:readShort();
                
                m_gamestate = GAMESTATE_GAMING;                
                if playerId ~= m_playerRoomIndex then
                    engine.__CMolBaseGUIContainer__:EnableControlById(IDD_MAINFRAME_HUOQI_BTN,true);
                end                
            elseif myMsgSubId == IDD_MESSAGE_GAMING_PINGJU then         -- ƽ��
                m_gamestate = GAMESTATE_WAITING;
                
                local myTextarea = toHelper.toMolGUITextarea(engine.__CMolBaseGUIContainer__:FindControlById(IDD_MAINFRAME_CHAT_MESSAGE));
                if myTextarea then
                    myTextarea:AddString("�˾�Ϊƽ�֡�",mole2d.CMolColor(255,255,0,0));
                end
                               
                engine.__CMolBaseGUIContainer__:EnableControlById(IDD_MAINFRAME_START_GAME,true);
                engine.__CMolBaseGUIContainer__:EnableControlById(IDD_MAINFRAME_HUIQI_BTN,false);
                engine.__CMolBaseGUIContainer__:EnableControlById(IDD_MAINFRAME_HUOQI_BTN,false);
                engine.__CMolBaseGUIContainer__:EnableControlById(IDD_MAINFRAME_RENSHU_BTN,false);
            elseif myMsgSubId == IDD_MESSAGE_GAMING_SHENGLI then        -- ����һ�ȡ��ʤ��
                local playerId = myMsg:readShort();
                local oldposx = myMsg:readShort();
                local oldposy = myMsg:readShort();
                
                if playerId ~= m_playerRoomIndex then
                    ProcessMouse(oldposx,oldposy,playerId+1);
                end
                
                -- ������Ϸ��������
                if playerId == m_playerRoomIndex then
                    engine:EffectPlay("sounds\\win.wav");
                else
                    engine:EffectPlay("sounds\\lost.wav");
                end
                
                m_gamestate = GAMESTATE_WAITING;
                
                local myTextarea = toHelper.toMolGUITextarea(engine.__CMolBaseGUIContainer__:FindControlById(IDD_MAINFRAME_CHAT_MESSAGE));
                if myTextarea then
                    myTextarea:AddString("���:"..tostring(playerId).."��ȡ��ʤ����",mole2d.CMolColor(255,255,0,0));
                end
                
                engine.__CMolBaseGUIContainer__:EnableControlById(IDD_MAINFRAME_START_GAME,true);
                engine.__CMolBaseGUIContainer__:EnableControlById(IDD_MAINFRAME_HUIQI_BTN,false);
                engine.__CMolBaseGUIContainer__:EnableControlById(IDD_MAINFRAME_HUOQI_BTN,false);
                engine.__CMolBaseGUIContainer__:EnableControlById(IDD_MAINFRAME_RENSHU_BTN,false);
            end
        end
	end		
end
